<?php
require 'config.php';

echo "<h2>Updating Database for Exam Results...</h2>";

// 1. Exams Table
$sql = "CREATE TABLE IF NOT EXISTS exams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT NOT NULL,
    subject VARCHAR(100) NOT NULL,
    exam_name VARCHAR(100) NOT NULL, -- e.g. 'Mid Term', 'Unit Test 1'
    academic_year VARCHAR(50) NOT NULL,
    exam_date DATE NOT NULL,
    max_marks INT NOT NULL,
    pass_marks INT DEFAULT 0,
    status ENUM('draft', 'published', 'scheduled', 'unpublished') DEFAULT 'draft',
    published_at DATETIME DEFAULT NULL, -- Marks when it should be/was published
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'exams' created/checked.<br>";
} else {
    echo "Error creating 'exams': " . $conn->error . "<br>";
}

// 2. Exam Marks Table
$sql = "CREATE TABLE IF NOT EXISTS exam_marks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    student_id INT NOT NULL,
    marks_obtained FLOAT DEFAULT 0,
    is_absent BOOLEAN DEFAULT FALSE,
    remarks VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_exam (exam_id, student_id)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'exam_marks' created/checked.<br>";
} else {
    echo "Error creating 'exam_marks': " . $conn->error . "<br>";
}

echo "<h3>Exam Module Setup Complete!</h3>";
?>