<?php
require '../config.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'student' && $_SESSION['role'] !== 'parent')) {
    redirect('../index.php');
}

$student_id = $_SESSION['user_id'];
if ($_SESSION['role'] == 'parent') {
    // Find linked student
    $p_res = $conn->query("SELECT id, class_id, full_name, username FROM users WHERE parent_id = $student_id AND role='student' LIMIT 1");
    if ($p_res->num_rows > 0) {
        $student_row = $p_res->fetch_assoc();
        $student_id = $student_row['id'];
        $class_id = $student_row['class_id'];
        $student_name = $student_row['full_name'];
        $adm_no = $student_row['username'];
    } else {
        die("No linked student found.");
    }
} else {
    // Role is student
    $class_id = $_SESSION['class_id'];
    $student_name = $_SESSION['full_name'];
    $adm_no = $_SESSION['username'];
}

// Fetch Published Exams
$now = date('Y-m-d H:i:s');
$exams_res = $conn->query("SELECT * FROM exams_multi 
        WHERE class_id = $class_id 
        AND (status = 'published' OR (status = 'scheduled' AND published_at <= '$now')) 
        ORDER BY start_date DESC");

?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4 slide-in"><i class="fas fa-certificate"></i> Exam Results (Multi-Subject)</h2>

<?php if ($exams_res->num_rows == 0): ?>
    <div class="glass slide-in" style="padding: 2rem; text-align: center; color: var(--text-muted);">
        <i class="fas fa-file-invoice fa-3x" style="margin-bottom: 1rem; opacity: 0.5;"></i>
        <p>No results published yet.</p>
    </div>
<?php else: ?>
    <div style="display: flex; flex-direction: column; gap: 2rem;">
        <?php while ($exam = $exams_res->fetch_assoc()):
            $exam_id = $exam['id'];

            // Fetch Subjects for this exam
            $subjects = [];
            $s_res = $conn->query("SELECT * FROM exam_subjects WHERE exam_id = $exam_id ORDER BY id ASC");
            while ($sub = $s_res->fetch_assoc())
                $subjects[] = $sub;

            // Fetch Marks
            $marks = [];
            $m_res = $conn->query("SELECT * FROM exam_marks_multi WHERE exam_id = $exam_id AND student_id = $student_id");
            while ($m = $m_res->fetch_assoc())
                $marks[$m['subject_id']] = $m;

            // Calculate Totals
            $total_max = 0;
            $total_obt = 0;
            $all_pass = true;

            foreach ($subjects as $sub) {
                $total_max += $sub['max_marks'];
                if (isset($marks[$sub['id']]) && !$marks[$sub['id']]['is_absent']) {
                    $total_obt += $marks[$sub['id']]['marks_obtained'];
                    if ($marks[$sub['id']]['marks_obtained'] < $sub['pass_marks'])
                        $all_pass = false;
                } elseif (isset($marks[$sub['id']]) && $marks[$sub['id']]['is_absent']) {
                    // Absent counts as fail usually, or just absent
                    $all_pass = false;
                } else {
                    // No marks entry? Treat as zero/fail
                    $all_pass = false;
                }
            }
            $percentage = $total_max > 0 ? round(($total_obt / $total_max) * 100, 2) : 0;
            $final_status = $all_pass ? "Passed" : "Failed"; // Simple logic
            ?>
            <!-- Result Card -->
            <div class="glass slide-in" style="border-radius: 1rem; overflow: hidden; position: relative;">
                <div
                    style="background: white; padding: 1.5rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <h2 style="color: var(--primary-color); margin: 0;"><?php echo $exam['exam_name']; ?></h2>
                        <p style="color: var(--text-muted); margin: 0.25rem 0;">Academic Year:
                            <?php echo $exam['academic_year']; ?></p>
                        <p style="font-size: 0.9rem; color: #666;">Date:
                            <?php echo date('d M Y', strtotime($exam['start_date'])); ?></p>
                    </div>

                    <button onclick="printResult('<?php echo md5($exam['exam_name']); ?>')" class="btn btn-secondary">
                        <i class="fas fa-download"></i> Download / Print
                    </button>
                </div>

                <!-- Printable Area -->
                <div id="print-<?php echo md5($exam['exam_name']); ?>" class="print-section">

                    <div class="print-header" style="display: none; text-align: center; margin-bottom: 2rem;">
                        <h1>CampusAuth Institute</h1>
                        <h3><?php echo $exam['exam_name']; ?> Report Card</h3>
                        <p>Student: <?php echo $student_name; ?> (<?php echo $adm_no; ?>)</p>
                    </div>

                    <table style="width: 100%; border-collapse: collapse;">
                        <thead style="background: rgba(99, 102, 241, 0.05);">
                            <tr>
                                <th style="padding: 1rem; text-align: left; border-bottom: 2px solid var(--border);">Subject
                                </th>
                                <th style="padding: 1rem; text-align: center; border-bottom: 2px solid var(--border);">Max Marks
                                </th>
                                <th style="padding: 1rem; text-align: center; border-bottom: 2px solid var(--border);">Pass
                                    Marks</th>
                                <th style="padding: 1rem; text-align: center; border-bottom: 2px solid var(--border);">Obtained
                                </th>
                                <th style="padding: 1rem; text-align: center; border-bottom: 2px solid var(--border);">Status
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subjects as $sub):
                                $sub_id = $sub['id'];
                                $m_entry = isset($marks[$sub_id]) ? $marks[$sub_id] : null;

                                $status = '-';
                                $color = 'black';
                                $obt_disp = '-';

                                if ($m_entry) {
                                    if ($m_entry['is_absent']) {
                                        $status = 'Absent';
                                        $color = 'orange'; // Changed to orange for Absent
                                        $obt_disp = 'AB';
                                    } else {
                                        $obt_disp = $m_entry['marks_obtained'];
                                        if ($obt_disp < $sub['pass_marks']) {
                                            $status = 'Fail';
                                            $color = 'red';
                                        } else {
                                            $status = 'Pass';
                                            $color = 'green';
                                        }
                                    }
                                } else {
                                    $status = 'N/A';
                                    $color = 'gray';
                                }
                                ?>
                                <tr style="border-bottom: 1px solid var(--border);">
                                    <td style="padding: 1rem;">
                                        <strong><?php echo $sub['subject_name']; ?></strong>
                                        <?php if ($sub['subject_code']): ?><span
                                                style="color: #999; font-size: 0.8em;">(<?php echo $sub['subject_code']; ?>)</span><?php endif; ?>
                                    </td>
                                    <td style="padding: 1rem; text-align: center; color: var(--text-muted);">
                                        <?php echo $sub['max_marks']; ?></td>
                                    <td style="padding: 1rem; text-align: center; color: var(--text-muted);">
                                        <?php echo $sub['pass_marks']; ?></td>
                                    <td style="padding: 1rem; text-align: center; font-weight: bold;">
                                        <?php echo $obt_disp; ?>
                                    </td>
                                    <td style="padding: 1rem; text-align: center; font-weight: bold; color: <?php echo $color; ?>;">
                                        <?php echo $status; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                            <!-- Totals -->
                            <tr style="background: #f9fafb; border-top: 2px solid #ddd;">
                                <td style="padding: 1rem; font-weight: bold;">Grand Total</td>
                                <td style="padding: 1rem; text-align: center; font-weight: bold;"><?php echo $total_max; ?></td>
                                <td></td>
                                <td style="padding: 1rem; text-align: center; font-weight: bold; color: var(--primary-color);">
                                    <?php echo $total_obt; ?>
                                </td>
                                <td
                                    style="padding: 1rem; text-align: center; font-weight: bold; color: <?php echo $all_pass ? 'green' : 'red'; ?>;">
                                    <?php echo $percentage; ?>%
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Result Footer -->
                    <div style="margin-top: 1rem; padding: 1rem; text-align: right;">
                        <span style="font-size: 1.2rem; font-weight: bold;">Final Result:
                            <span style="color: <?php echo $all_pass ? 'green' : 'red'; ?>;"><?php echo $final_status; ?></span>
                        </span>
                    </div>

                    <div class="print-footer"
                        style="display: none; margin-top: 3rem; text-align: center; font-size: 0.8rem; color: #666;">
                        <p>Generated on <?php echo date('d M Y'); ?> via CampusAuth System</p>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
<?php endif; ?>

<style>
    @media print {
        body * {
            visibility: hidden;
        }

        .print-section,
        .print-section * {
            visibility: visible;
        }

        .print-section {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            background: white;
            color: black;
        }

        .print-header,
        .print-footer {
            display: block !important;
        }

        .btn,
        .sidebar,
        .top-header {
            display: none !important;
        }

        table,
        th,
        td {
            border: 1px solid #ddd !important;
        }

        .glass {
            box-shadow: none !important;
            border: none !important;
        }
    }
</style>

<script>
    function printResult(id) {
        let content = document.getElementById('print-' + id).innerHTML;
        let original = document.body.innerHTML;
        document.body.innerHTML = content;
        window.print();
        document.body.innerHTML = original;
        location.reload();
    }
</script>

<?php include '../includes/footer.php'; ?>