<?php
require '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$class_id = $_SESSION['class_id'];

// Check First Time Login
$u_check = $conn->query("SELECT is_first_login FROM users WHERE id = $student_id")->fetch_assoc();
if ($u_check && $u_check['is_first_login'] == 1) {
    header("Location: first_time_setup.php");
    exit();
}

// Current Month/Year
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Month Navigation
$prev_month = $month - 1;
$prev_year = $year;
if ($prev_month < 1) {
    $prev_month = 12;
    $prev_year--;
}

$next_month = $month + 1;
$next_year = $year;
if ($next_month > 12) {
    $next_month = 1;
    $next_year++;
}

// Fetch Attendance Data
$start_date = "$year-" . str_pad($month, 2, '0', STR_PAD_LEFT) . "-01";
$end_date = date("Y-m-t", strtotime($start_date));

$sql = "SELECT DAY(date) as day, status, remarks FROM attendance 
        WHERE student_id = $student_id AND date BETWEEN '$start_date' AND '$end_date'";
$result = $conn->query($sql);

$attendance_map = [];
while ($row = $result->fetch_assoc()) {
    $attendance_map[$row['day']] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h2><i class="fas fa-calendar-alt"></i> Attendance Calendar</h2>
    <div
        style="display: flex; gap: 1rem; align-items: center; background: white; padding: 0.5rem 1rem; border-radius: 0.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        <a href="?month=<?php echo $prev_month; ?>&year=<?php echo $prev_year; ?>" class="btn-icon">
            <i class="fas fa-chevron-left"></i>
        </a>
        <h3 style="margin: 0; min-width: 150px; text-align: center;">
            <?php echo date("F Y", strtotime("$year-$month-01")); ?>
        </h3>
        <a href="?month=<?php echo $next_month; ?>&year=<?php echo $next_year; ?>" class="btn-icon">
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>
</div>

<div class="glass" style="padding: 1.5rem; border-radius: 1rem;">
    <!-- Legend -->
    <div style="display: flex; gap: 1.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; justify-content: center;">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span style="width: 12px; height: 12px; border-radius: 50%; background: #10b981;"></span> Present
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span style="width: 12px; height: 12px; border-radius: 50%; background: #ef4444;"></span> Absent
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span style="width: 12px; height: 12px; border-radius: 50%; background: #f59e0b;"></span> Half Day
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span style="width: 12px; height: 12px; border-radius: 50%; background: #6366f1;"></span> Leave
        </div>
    </div>

    <!-- Calendar Grid -->
    <div class="calendar-grid">
        <!-- Days Header -->
        <div class="cal-day-header">Sun</div>
        <div class="cal-day-header">Mon</div>
        <div class="cal-day-header">Tue</div>
        <div class="cal-day-header">Wed</div>
        <div class="cal-day-header">Thu</div>
        <div class="cal-day-header">Fri</div>
        <div class="cal-day-header">Sat</div>

        <?php
        // Logic to draw days
        $days_in_month = date('t', strtotime("$year-$month-01"));
        $first_day_of_week = date('w', strtotime("$year-$month-01")); // 0 (Sun) to 6 (Sat)
        
        // Empty slots
        for ($i = 0; $i < $first_day_of_week; $i++) {
            echo '<div class="cal-day empty"></div>';
        }

        // Days
        for ($day = 1; $day <= $days_in_month; $day++) {
            $is_weekend = false; // logic for weekend if needed
            $status_class = '';
            $status_icon = '';
            $title = '';

            if (isset($attendance_map[$day])) {
                $status = $attendance_map[$day]['status'];
                $remarks = $attendance_map[$day]['remarks'];

                if ($status == 'present') {
                    $status_class = 'present';
                    $status_icon = '<i class="fas fa-check"></i>';
                } elseif ($status == 'absent') {
                    $status_class = 'absent';
                    $status_icon = '<i class="fas fa-times"></i>';
                } elseif ($status == 'half_day') {
                    $status_class = 'half';
                    $status_icon = '<i class="fas fa-adjust"></i>';
                } elseif ($status == 'leave') {
                    $status_class = 'leave';
                    $status_icon = '<i class="fas fa-plane"></i>';
                }

                $title = ucfirst(str_replace('_', ' ', $status));
                if ($remarks)
                    $title .= " - Note: $remarks";
            } else {
                // Check if weekend?
                // Calculate day of week for this specific date
                $current_dow = date('w', strtotime("$year-$month-$day"));
                if ($current_dow == 0 || $current_dow == 6) {
                    $status_class = 'weekend';
                }
            }

            // Highlight Today
            $is_today = ($day == date('j') && $month == date('n') && $year == date('Y')) ? 'today' : '';

            echo "<div class='cal-day $status_class $is_today' title='$title'>";
            echo "<span class='day-num'>$day</span>";
            if ($status_icon) {
                echo "<span class='day-status'>$status_icon</span>";
            }
            echo "</div>";
        }
        ?>
    </div>
</div>

<style>
    .calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 0.5rem;
    }

    .cal-day-header {
        text-align: center;
        font-weight: 600;
        color: var(--text-muted);
        padding: 0.5rem;
    }

    .cal-day {
        min-height: 80px;
        background: rgba(255, 255, 255, 0.5);
        border: 1px solid var(--border);
        border-radius: 0.5rem;
        padding: 0.5rem;
        position: relative;
        transition: transform 0.2s;
    }

    .cal-day:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .cal-day.empty {
        background: transparent;
        border: none;
    }

    .day-num {
        font-weight: 600;
        font-size: 0.9rem;
        color: var(--text-main);
    }

    .day-status {
        position: absolute;
        bottom: 5px;
        right: 5px;
        font-size: 1.2rem;
    }

    /* Status Colors */
    .cal-day.present {
        background: #d1fae5;
        border-color: #10b981;
        color: #065f46;
    }

    .cal-day.absent {
        background: #fee2e2;
        border-color: #ef4444;
        color: #991b1b;
    }

    .cal-day.half {
        background: #fef3c7;
        border-color: #f59e0b;
        color: #92400e;
    }

    .cal-day.leave {
        background: #e0e7ff;
        border-color: #6366f1;
        color: #3730a3;
    }

    .cal-day.weekend {
        background: #f3f4f6;
        color: #9ca3af;
    }

    .cal-day.today {
        border: 2px solid var(--primary-color);
    }

    .btn-icon {
        color: var(--text-main);
        padding: 0.5rem;
        border-radius: 50%;
        transition: background 0.2s;
    }

    .btn-icon:hover {
        background: #f3f4f6;
    }
</style>

<?php include '../includes/footer.php'; ?>