<?php
require '../config.php';

// Check Session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if actually first login
$check = $conn->query("SELECT is_first_login, username FROM users WHERE id = $user_id")->fetch_assoc();
if (!$check['is_first_login']) {
    // Already set up
    header("Location: dashboard.php");
    exit();
}

$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($full_name) || empty($password)) {
        $message = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $message = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {
        $new_hash = password_hash($password, PASSWORD_BCRYPT);
        // Update User
        $stmt = $conn->prepare("UPDATE users SET full_name = ?, password = ?, is_first_login = 0 WHERE id = ?");
        $stmt->bind_param("ssi", $full_name, $new_hash, $user_id);

        if ($stmt->execute()) {
            $_SESSION['full_name'] = $full_name; // Update session name
            // Redirect to dashboard with success
            header("Location: dashboard.php");
            exit();
        } else {
            $message = "Error updating profile. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Time Setup | CampusAuth</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background: #f3f4f6;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .setup-card {
            background: white;
            padding: 2.5rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
        }

        .h-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: #111827;
        }
    </style>
</head>

<body>

    <div class="setup-card">
        <div style="text-align: center; margin-bottom: 2rem;">
            <h1 class="h-title">Welcome Aboard! 🎉</h1>
            <p style="color: #6b7280;">Please set up your account to continue.</p>
        </div>

        <?php if ($message): ?>
            <div
                style="background: #fee2e2; color: #b91c1c; padding: 0.75rem; border-radius: 0.5rem; margin-bottom: 1rem; font-size: 0.9rem;">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group" style="margin-bottom: 1.5rem;">
                <label style="display: block; font-weight: 500; margin-bottom: 0.5rem; color: #374151;">Full
                    Name</label>
                <input type="text" name="full_name" placeholder="Enter your full name" required
                    style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-family: inherit;">
            </div>

            <div class="form-group" style="margin-bottom: 1.5rem;">
                <label style="display: block; font-weight: 500; margin-bottom: 0.5rem; color: #374151;">New
                    Password</label>
                <input type="password" name="password" placeholder="Create a strong password" required
                    style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-family: inherit;">
            </div>

            <div class="form-group" style="margin-bottom: 2rem;">
                <label style="display: block; font-weight: 500; margin-bottom: 0.5rem; color: #374151;">Confirm
                    Password</label>
                <input type="password" name="confirm_password" placeholder="Repeat password" required
                    style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-family: inherit;">
            </div>

            <button type="submit"
                style="width: 100%; padding: 0.875rem; background: #4f46e5; color: white; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; transition: background 0.2s;">
                Save & Continue
            </button>

            <div style="margin-top: 1rem; text-align: center; font-size: 0.85rem; color: #6b7280;">
                <i class="fas fa-lock"></i> Default password will be invalidated.
            </div>
        </form>
    </div>

</body>

</html>