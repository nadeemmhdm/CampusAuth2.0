<?php
require 'config.php';

echo "<h2>Fixing Database Schema (All Versions + Multi-Subject)...</h2>";

function add_column_if_not_exists($conn, $table, $column, $definition)
{
    if ($conn->query("SHOW TABLES LIKE '$table'")->num_rows > 0) {
        $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
        if ($check->num_rows == 0) {
            $sql = "ALTER TABLE $table ADD COLUMN $column $definition";
            if ($conn->query($sql) === TRUE) {
                echo "✅ Added column '$column' to '$table'.<br>";
            } else {
                echo "❌ Error adding '$column': " . $conn->error . "<br>";
            }
        }
    }
}

// 1. Security Columns (V7)
add_column_if_not_exists($conn, 'users', 'is_first_login', 'BOOLEAN DEFAULT FALSE');
add_column_if_not_exists($conn, 'users', 'failed_login_attempts', 'INT DEFAULT 0');
add_column_if_not_exists($conn, 'users', 'lockout_time', 'TIMESTAMP NULL DEFAULT NULL');

// 2. Tracking Columns (Login Logic)
add_column_if_not_exists($conn, 'users', 'last_login_at', 'DATETIME DEFAULT NULL');
add_column_if_not_exists($conn, 'users', 'last_login_ip', 'VARCHAR(45) DEFAULT NULL');
add_column_if_not_exists($conn, 'users', 'last_login_device', 'VARCHAR(255) DEFAULT NULL');
add_column_if_not_exists($conn, 'users', 'first_login_at', 'DATETIME DEFAULT NULL');
add_column_if_not_exists($conn, 'users', 'first_login_ip', 'VARCHAR(45) DEFAULT NULL');
add_column_if_not_exists($conn, 'users', 'first_login_device', 'VARCHAR(255) DEFAULT NULL');

// 3. Exam Tables (V8 - Single Subject Legacy)
$sql = "CREATE TABLE IF NOT EXISTS exams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT NOT NULL,
    subject VARCHAR(100) NOT NULL,
    exam_name VARCHAR(100) NOT NULL,
    academic_year VARCHAR(50) NOT NULL,
    exam_date DATE NOT NULL,
    max_marks INT NOT NULL,
    pass_marks INT DEFAULT 0,
    status ENUM('draft', 'published', 'scheduled', 'unpublished') DEFAULT 'draft',
    published_at DATETIME DEFAULT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exams' verified.<br>";
else
    echo "❌ Error 'exams': " . $conn->error . "<br>";

$sql = "CREATE TABLE IF NOT EXISTS exam_marks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    student_id INT NOT NULL,
    marks_obtained FLOAT DEFAULT 0,
    is_absent BOOLEAN DEFAULT FALSE,
    remarks VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_student_exam (exam_id, student_id)
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exam_marks' verified.<br>";
else
    echo "❌ Error 'exam_marks': " . $conn->error . "<br>";

// 4. Multi-Subject Exam Tables (V9)
$sql = "CREATE TABLE IF NOT EXISTS exams_multi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT NOT NULL,
    exam_name VARCHAR(100) NOT NULL, 
    academic_year VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('draft', 'published', 'scheduled', 'unpublished') DEFAULT 'draft',
    published_at DATETIME DEFAULT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exams_multi' verified.<br>";
else
    echo "❌ Error 'exams_multi': " . $conn->error . "<br>";

$sql = "CREATE TABLE IF NOT EXISTS exam_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20) DEFAULT NULL,
    max_marks INT DEFAULT 100,
    pass_marks INT DEFAULT 40,
    FOREIGN KEY (exam_id) REFERENCES exams_multi(id) ON DELETE CASCADE
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exam_subjects' verified.<br>";
else
    echo "❌ Error 'exam_subjects': " . $conn->error . "<br>";

$sql = "CREATE TABLE IF NOT EXISTS exam_marks_multi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    subject_id INT NOT NULL,
    student_id INT NOT NULL,
    marks_obtained FLOAT DEFAULT 0,
    is_absent BOOLEAN DEFAULT FALSE,
    remarks VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (exam_id) REFERENCES exams_multi(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES exam_subjects(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_mark (exam_id, subject_id, student_id)
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exam_marks_multi' verified.<br>";
else
    echo "❌ Error 'exam_marks_multi': " . $conn->error . "<br>";


echo "<h3>Database Repair Complete!</h3>";
echo "<p><a href='index.php'>Go to Login</a> | <a href='admin/dashboard.php'>Go to Admin Dashboard</a></p>";
?>