<?php
require 'config.php';

echo "<h2>Upgrading Database for Multi-Subject Exams...</h2>";

// 1. Exams Table (New Structure)
// We will create a new table to avoid breaking existing data immediately, 
// but logically this replaces the old 'exams' table.
$sql = "CREATE TABLE IF NOT EXISTS exams_multi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_id INT NOT NULL,
    exam_name VARCHAR(100) NOT NULL, -- e.g. 'Mid Term'
    academic_year VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('draft', 'published', 'scheduled', 'unpublished') DEFAULT 'draft',
    published_at DATETIME DEFAULT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exams_multi' ready.<br>";
else
    echo "❌ Error 'exams_multi': " . $conn->error . "<br>";

// 2. Exam Subjects Table
$sql = "CREATE TABLE IF NOT EXISTS exam_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20) DEFAULT NULL,
    max_marks INT DEFAULT 100,
    pass_marks INT DEFAULT 40,
    FOREIGN KEY (exam_id) REFERENCES exams_multi(id) ON DELETE CASCADE
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exam_subjects' ready.<br>";
else
    echo "❌ Error 'exam_subjects': " . $conn->error . "<br>";

// 3. Exam Marks Table (Multi-Subject)
$sql = "CREATE TABLE IF NOT EXISTS exam_marks_multi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    subject_id INT NOT NULL,
    student_id INT NOT NULL,
    marks_obtained FLOAT DEFAULT 0,
    is_absent BOOLEAN DEFAULT FALSE,
    remarks VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (exam_id) REFERENCES exams_multi(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES exam_subjects(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_mark (exam_id, subject_id, student_id)
)";
if ($conn->query($sql) === TRUE)
    echo "✅ Table 'exam_marks_multi' ready.<br>";
else
    echo "❌ Error 'exam_marks_multi': " . $conn->error . "<br>";

echo "<h3>Upgrade Complete!</h3>";
?>