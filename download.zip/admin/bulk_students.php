<?php
require '../config.php';

// Check Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$message = '';
$summary = [];

// Fetch Classes
$classes = $conn->query("SELECT * FROM classes ORDER BY class_name");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $start_adm = trim($_POST['start_adm']);
    $end_adm = trim($_POST['end_adm']);
    $class_id = intval($_POST['class_id']);
    $academic_year = trim($_POST['academic_year']);

    // Parse Start/End Admission Numbers
    // Regex to separate prefix and number: (Anything)(Digits)
    if (preg_match('/^(.*)(\d+)$/', $start_adm, $start_matches) && preg_match('/^(.*)(\d+)$/', $end_adm, $end_matches)) {
        $prefix_start = $start_matches[1];
        $num_start = $start_matches[2];

        $prefix_end = $end_matches[1];
        $num_end = $end_matches[2];

        if ($prefix_start !== $prefix_end) {
            $message = "Error: Start and End admission numbers must have the same prefix (e.g. 2023CS).";
        } else {
            $prefix = $prefix_start;
            $start_val = intval($num_start);
            $end_val = intval($num_end);
            $pad_len = strlen($num_start); // Maintain zero padding

            if ($start_val > $end_val) {
                $message = "Error: Start number cannot be greater than end number.";
            } else {
                $count_created = 0;
                $count_skipped = 0;
                $total_processed = 0;

                // Loop
                for ($i = $start_val; $i <= $end_val; $i++) {
                    $total_processed++;
                    $current_num_str = str_pad($i, $pad_len, '0', STR_PAD_LEFT);
                    $adm_no = $prefix . $current_num_str;

                    // Check if exists
                    $check = $conn->query("SELECT id FROM users WHERE username = '$adm_no'");
                    if ($check->num_rows > 0) {
                        $summary[] = "<span style='color: orange;'>Skipped (Exists): $adm_no</span>";
                        $count_skipped++;
                        continue;
                    }

                    // Create Student
                    // Password = Demo123@
                    $password_hash = password_hash("Demo123@", PASSWORD_BCRYPT);
                    // Name = Admission No (Initially)
                    $full_name = $adm_no;

                    // Insert Student
                    // is_first_login = 1
                    $sql_student = "INSERT INTO users (username, password, role, full_name, class_id, status, is_first_login, created_at) 
                                    VALUES ('$adm_no', '$password_hash', 'student', '$full_name', $class_id, 'active', 1, NOW())";

                    if ($conn->query($sql_student)) {
                        $student_id = $conn->insert_id;

                        // Create Parent
                        // Format: P + AdmNo (e.g. P2023CS001) or just use AdmNo_P? 
                        // Prompt says "Parent account creation uses Admission Number". 
                        // Let's use P_AdmissionNumber as username to be unique.
                        $parent_user = "P_" . $adm_no;
                        $parent_pass = $password_hash; // Same default password
                        $parent_name = "Parent of " . $adm_no;

                        $sql_parent = "INSERT INTO users (username, password, role, full_name, status, created_at) 
                                       VALUES ('$parent_user', '$parent_pass', 'parent', '$parent_name', 'active', NOW())";

                        if ($conn->query($sql_parent)) {
                            $parent_id = $conn->insert_id;
                            // Link
                            $conn->query("UPDATE users SET parent_id = $parent_id WHERE id = $student_id");
                        }

                        $summary[] = "<span style='color: green;'>Created: $adm_no</span>";
                        $count_created++;
                    } else {
                        $summary[] = "<span style='color: red;'>Error ($adm_no): " . $conn->error . "</span>";
                    }
                }
                $message = "Batch Processed: Created $count_created, Skipped $count_skipped.";
            }
        }
    } else {
        $message = "Error: Invalid Admission Number format. Must end with numbers (e.g. 2023CS001).";
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container" style="max-width: 800px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2><i class="fas fa-users-cog"></i> Bulk Student Creation</h2>
        <a href="manage_users.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <?php if ($message): ?>
        <div
            style="padding: 1rem; background: #e0f2fe; color: #0369a1; border-radius: 0.5rem; margin-bottom: 1rem; border: 1px solid #bae6fd;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div class="glass" style="padding: 2rem; border-radius: 1rem;">
        <form method="POST">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label>Start Admission Number</label>
                    <input type="text" name="start_adm" placeholder="e.g. 2023CS001" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 0.5rem;">
                </div>
                <div class="form-group">
                    <label>End Admission Number</label>
                    <input type="text" name="end_adm" placeholder="e.g. 2023CS120" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 0.5rem;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                <div class="form-group">
                    <label>Class / Section</label>
                    <select name="class_id" required
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 0.5rem;">
                        <option value="">Select Class</option>
                        <?php while ($c = $classes->fetch_assoc()): ?>
                            <option value="<?php echo $c['id']; ?>">
                                <?php echo $c['class_name'] . " (" . $c['academic_year'] . ")"; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Academic Year</label>
                    <input type="text" name="academic_year" placeholder="e.g. 2023-2024"
                        style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 0.5rem;">
                    <small style="color: grey;">Used for reference</small>
                </div>
            </div>

            <div style="margin-top: 2rem;">
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 1rem; font-size: 1.1rem;">
                    <i class="fas fa-magic"></i> Create Accounts
                </button>
            </div>
        </form>
    </div>

    <?php if (!empty($summary)): ?>
        <div class="glass" style="margin-top: 2rem; padding: 1.5rem; border-radius: 1rem;">
            <h3>Creation Summary</h3>
            <div
                style="max-height: 300px; overflow-y: auto; background: #f9fafb; padding: 1rem; border-radius: 0.5rem; border: 1px solid #eee;">
                <?php foreach ($summary as $line): ?>
                    <div style="margin-bottom: 0.25rem; font-family: monospace;">
                        <?php echo $line; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>