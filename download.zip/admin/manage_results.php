<?php
require '../config.php';

// Check Role
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'teacher' && $_SESSION['role'] !== 'admin')) {
    redirect('../index.php');
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Handle Actions
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $exam_id = intval($_POST['exam_id']);
        $where_owner = ($role == 'teacher') ? "AND created_by = $user_id" : "";

        if ($_POST['action'] == 'delete') {
            $conn->query("DELETE FROM exams_multi WHERE id = $exam_id $where_owner");
            $message = "Exam deleted successfully.";
        } elseif ($_POST['action'] == 'unpublish') {
            $conn->query("UPDATE exams_multi SET status = 'unpublished' WHERE id = $exam_id $where_owner");
            $message = "Exam unpublished.";
        } elseif ($_POST['action'] == 'publish_now') {
            $now = date('Y-m-d H:i:s');
            $conn->query("UPDATE exams_multi SET status = 'published', published_at = '$now' WHERE id = $exam_id $where_owner");
            $message = "Exam published immediately.";
        }
    }
}

// Fetch Exams
// Admin sees all, Teacher sees own
// We join with classes for class_name
$sql = "SELECT e.*, c.class_name 
        FROM exams_multi e 
        LEFT JOIN classes c ON e.class_id = c.id 
        WHERE 1=1 ";

if ($role == 'teacher') {
    $sql .= "AND e.created_by = $user_id ";
}
$sql .= "ORDER BY e.created_at DESC";

$exams = $conn->query($sql);
?>
<?php include '../includes/header.php'; ?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h2><i class="fas fa-poll"></i> Exam Results (Multi-Subject)</h2>
    <a href="add_result.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Result
    </a>
</div>

<?php if ($message): ?>
    <div style="padding: 1rem; background: #d1fae5; color: #065f46; border-radius: 0.5rem; margin-bottom: 1rem;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<!-- Dashboard Cards Summary -->
<?php
$total_exams = $exams->num_rows;
$published = 0;
$draft = 0;
$exam_list = [];
while ($row = $exams->fetch_assoc()) {
    $exam_list[] = $row;
    if ($row['status'] == 'published')
        $published++;
    if ($row['status'] == 'draft')
        $draft++;
}
?>

<div class="stats-grid" style="margin-bottom: 2rem;">
    <div class="stat-card">
        <div class="stat-icon" style="color: var(--primary-color);"><i class="fas fa-file-alt"></i></div>
        <div>
            <h3><?php echo $total_exams; ?></h3>
            <p>Total Exams</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="color: green;"><i class="fas fa-check-circle"></i></div>
        <div>
            <h3><?php echo $published; ?></h3>
            <p>Published</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="color: orange;"><i class="fas fa-pencil-alt"></i></div>
        <div>
            <h3><?php echo $draft; ?></h3>
            <p>Drafts</p>
        </div>
    </div>
</div>

<div class="glass" style="border-radius: 1rem; overflow: hidden;">
    <table style="width: 100%; border-collapse: collapse;">
        <thead style="background: rgba(99, 102, 241, 0.1);">
            <tr>
                <th style="padding: 1rem; text-align: left;">Exam Name</th>
                <th style="padding: 1rem; text-align: left;">Class</th>
                <th style="padding: 1rem; text-align: left;">Dates</th>
                <th style="padding: 1rem; text-align: center;">Status</th>
                <th style="padding: 1rem; text-align: right;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($exam_list) > 0): ?>
                <?php foreach ($exam_list as $e): ?>
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 1rem;">
                            <strong><?php echo $e['exam_name']; ?></strong>
                            <div class="text-muted" style="font-size: 0.8rem;"><?php echo $e['academic_year']; ?></div>
                        </td>
                        <td style="padding: 1rem; color: var(--primary-color);">
                            <?php echo $e['class_name']; ?>
                        </td>
                        <td style="padding: 1rem; font-size: 0.9rem;">
                            <?php echo date('d M', strtotime($e['start_date'])); ?> -
                            <?php echo date('d M Y', strtotime($e['end_date'])); ?>
                        </td>
                        <td style="padding: 1rem; text-align: center;">
                            <?php
                            $status_color = 'grey';
                            $status_text = ucfirst($e['status']);
                            if ($e['status'] == 'published')
                                $status_color = 'green';
                            if ($e['status'] == 'scheduled')
                                $status_color = 'blue';
                            if ($e['status'] == 'unpublished')
                                $status_color = 'red';
                            ?>
                            <span
                                style="background: <?php echo $status_color == 'green' ? '#d1fae5' : '#f3f4f6'; ?>; 
                                       color: <?php echo $status_color == 'green' ? 'green' : $status_color; ?>; 
                                       padding: 0.25rem 0.75rem; border-radius: 1rem; font-size: 0.85rem; font-weight: 600;">
                                <?php echo $status_text; ?>
                            </span>
                            <?php if ($e['status'] == 'scheduled'): ?>
                                <div style="font-size: 0.75rem; color: blue; margin-top: 0.2rem;">
                                    <?php echo date('d M, H:i', strtotime($e['published_at'])); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 1rem; text-align: right;">
                            <div style="display: flex; gap: 0.5rem; justify-content: flex-end;">
                                <a href="add_result.php?edit_id=<?php echo $e['id']; ?>" class="btn" title="Edit"
                                    style="padding: 0.5rem; background: #3b82f6; color: white;">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <?php if ($e['status'] == 'published'): ?>
                                    <form method="POST" onsubmit="return confirm('Unpublish this result?');">
                                        <input type="hidden" name="action" value="unpublish">
                                        <input type="hidden" name="exam_id" value="<?php echo $e['id']; ?>">
                                        <button class="btn" title="Unpublish"
                                            style="padding: 0.5rem; background: #f59e0b; color: white;">
                                            <i class="fas fa-eye-slash"></i>
                                        </button>
                                    </form>
                                <?php elseif ($e['status'] == 'draft' || $e['status'] == 'unpublished'): ?>
                                    <form method="POST" onsubmit="return confirm('Publish now?');">
                                        <input type="hidden" name="action" value="publish_now">
                                        <input type="hidden" name="exam_id" value="<?php echo $e['id']; ?>">
                                        <button class="btn" title="Publish Now"
                                            style="padding: 0.5rem; background: #10b981; color: white;">
                                            <i class="fas fa-upload"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <form method="POST" onsubmit="return confirm('Delete this exam permanently?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="exam_id" value="<?php echo $e['id']; ?>">
                                    <button class="btn" title="Delete"
                                        style="padding: 0.5rem; background: #ef4444; color: white;">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="padding: 2rem; text-align: center; color: var(--text-muted);">
                        No results found. Click "Add New Result" to start.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>