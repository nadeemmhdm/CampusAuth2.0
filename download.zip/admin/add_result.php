<?php
require '../config.php';

// Check Role
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'teacher' && $_SESSION['role'] !== 'admin')) {
    redirect('../index.php');
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$message = '';
$exam_id = isset($_GET['edit_id']) ? intval($_GET['edit_id']) : 0;

// Initialize Variables
$exam = [
    'exam_name' => '', 'class_id' => '', 'academic_year' => '', 
    'start_date' => date('Y-m-d'), 'end_date' => date('Y-m-d'), 
    'status' => 'draft', 'published_at' => ''
];
$subjects = []; // Array of {id, subject_name, subject_code, max, pass}
$marks_data = []; // [student_id][subject_id] => {obt, absent}

// Load Existing Exam
if ($exam_id) {
    $res = $conn->query("SELECT * FROM exams_multi WHERE id = $exam_id");
    if ($res->num_rows > 0) {
        $exam = $res->fetch_assoc();
        
        // Security Check
        if ($role == 'teacher' && $exam['created_by'] != $user_id) die("Unauthorized");
        
        // Load Subjects
        $sub_res = $conn->query("SELECT * FROM exam_subjects WHERE exam_id = $exam_id ORDER BY id ASC");
        while ($sub = $sub_res->fetch_assoc()) {
            $subjects[] = $sub;
        }

        // Load Marks
        $m_res = $conn->query("SELECT * FROM exam_marks_multi WHERE exam_id = $exam_id");
        while ($m = $m_res->fetch_assoc()) {
            $marks_data[$m['student_id']][$m['subject_id']] = $m;
        }
    } else {
        die("Exam not found");
    }
}

// Fetch Classes
if ($role == 'teacher') {
    $classes = $conn->query("SELECT * FROM classes WHERE tutor_id = $user_id");
} else {
    $classes = $conn->query("SELECT * FROM classes");
}

// Handle POST Save
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $exam_name = $conn->real_escape_string($_POST['exam_name']);
    $class_id = intval($_POST['class_id']);
    $academic_year = $conn->real_escape_string($_POST['academic_year']);
    $start_date = $conn->real_escape_string($_POST['start_date']);
    $end_date = $conn->real_escape_string($_POST['end_date']);
    
    // Status Logic
    $status = 'draft';
    $published_at = 'NULL';
    if (isset($_POST['publish_now'])) {
        $status = 'published';
        $published_at = "'" . date('Y-m-d H:i:s') . "'";
    } elseif (isset($_POST['schedule_publish'])) {
        $status = 'scheduled';
        $published_at = "'" . $_POST['pub_date'] . ' ' . $_POST['pub_time'] . "'";
    } elseif ($exam_id && $exam['status'] != 'draft') {
        $status = $exam['status']; // Keep existing status if just saving draft updates on live exam
        $published_at = $exam['published_at'] ? "'" . $exam['published_at'] . "'" : 'NULL';
    }

    // 1. Save Header
    if ($exam_id) {
        $sql = "UPDATE exams_multi SET 
                exam_name='$exam_name', class_id=$class_id, academic_year='$academic_year', 
                start_date='$start_date', end_date='$end_date', 
                status='$status', published_at=$published_at 
                WHERE id=$exam_id";
        $conn->query($sql);
    } else {
        $sql = "INSERT INTO exams_multi (class_id, exam_name, academic_year, start_date, end_date, status, published_at, created_by) 
                VALUES ($class_id, '$exam_name', '$academic_year', '$start_date', '$end_date', '$status', $published_at, $user_id)";
        if ($conn->query($sql)) {
            $exam_id = $conn->insert_id;
        } else {
            die("Error: " . $conn->error);
        }
    }

    // 2. Save Subjects
    $current_sub_ids = [];
    if ($exam_id) {
        $c_res = $conn->query("SELECT id FROM exam_subjects WHERE exam_id = $exam_id");
        while($r = $c_res->fetch_assoc()) $current_sub_ids[] = $r['id'];
    }

    $posted_sub_ids = [];
    
    if (isset($_POST['subjects'])) {
        foreach ($_POST['subjects'] as $idx => $s_data) {
            $s_name = $conn->real_escape_string($s_data['name']);
            $s_code = $conn->real_escape_string($s_data['code']);
            $max = intval($s_data['max']);
            $pass = intval($s_data['pass']);
            $sid = isset($s_data['id']) && $s_data['id'] ? intval($s_data['id']) : 0;

            if ($sid && in_array($sid, $current_sub_ids)) {
                $conn->query("UPDATE exam_subjects SET subject_name='$s_name', subject_code='$s_code', max_marks=$max, pass_marks=$pass WHERE id=$sid");
                $posted_sub_ids[] = $sid;
            } else {
                $conn->query("INSERT INTO exam_subjects (exam_id, subject_name, subject_code, max_marks, pass_marks) VALUES ($exam_id, '$s_name', '$s_code', $max, $pass)");
            }
        }
    }
    
    foreach ($current_sub_ids as $cid) {
        if (!in_array($cid, $posted_sub_ids)) {
             $conn->query("DELETE FROM exam_subjects WHERE id = $cid");
        }
    }

    // 3. Save Marks
    if (isset($_POST['marks'])) {
        foreach ($_POST['marks'] as $st_id => $sub_marks) {
            foreach ($sub_marks as $sub_id => $m_val) {
                // m_val is array {obt, absent}
                $obt = isset($m_val['obt']) && $m_val['obt'] !== '' ? floatval($m_val['obt']) : 0;
                $is_absent = isset($m_val['absent']) ? 1 : 0;
                if ($is_absent) $obt = 0;

                // Update/Insert
                $sql = "INSERT INTO exam_marks_multi (exam_id, subject_id, student_id, marks_obtained, is_absent) 
                        VALUES ($exam_id, $sub_id, $st_id, $obt, $is_absent) 
                        ON DUPLICATE KEY UPDATE marks_obtained=$obt, is_absent=$is_absent";
                $conn->query($sql);
            }
        }
    }

    $message = "Result saved successfully!";
    if (!headers_sent()) {
        header("Location: ?edit_id=$exam_id&msg=saved");
        exit();
    }
}

if (isset($_GET['msg'])) $message = "Results Saved Successfully.";

// Fetch Students
$students = [];
$target_class = $exam['class_id'] ? $exam['class_id'] : (isset($_GET['sel_class']) ? intval($_GET['sel_class']) : 0);
if ($target_class) {
    $s_res = $conn->query("SELECT * FROM users WHERE class_id = $target_class AND role = 'student' ORDER BY username ASC");
    while($s = $s_res->fetch_assoc()) $students[] = $s;
}

// Fetch Refresh Subjects (in case of save)
$subjects = [];
if ($exam_id) {
    $sub_res = $conn->query("SELECT * FROM exam_subjects WHERE exam_id = $exam_id ORDER BY id ASC");
    while ($sub = $sub_res->fetch_assoc()) $subjects[] = $sub;
}
?>

<?php include '../includes/header.php'; ?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h2><i class="fas fa-layer-group"></i> Multi-Subject Result Entry</h2>
    <a href="manage_results.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<?php if ($message): ?>
    <div style="padding: 1rem; background: #d1fae5; color: #065f46; border-radius: 0.5rem; margin-bottom: 1rem;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<form method="POST" id="mainForm">
    <!-- SECTION 1: EXAM INFO -->
    <div class="glass" style="padding: 1.5rem; border-radius: 1rem; margin-bottom: 1.5rem;">
        <h3 style="margin-bottom: 1rem; color: var(--primary-color);">1. Exam Configuration</h3>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;">
            <div class="form-group">
                <label>Exam Name</label>
                <input type="text" name="exam_name" required value="<?php echo $exam['exam_name']; ?>" placeholder="e.g. Final Exams">
            </div>
            <div class="form-group">
                <label>Academic Year</label>
                <input type="text" name="academic_year" required value="<?php echo $exam['academic_year']; ?>" placeholder="e.g. 2023-2024">
            </div>
            <div class="form-group">
                <label>Class</label>
                <select name="class_id" required onchange="saveDraftAndReload(this.value)">
                    <option value="">Select Class</option>
                    <?php 
                    $classes->data_seek(0);
                    while ($c = $classes->fetch_assoc()): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $target_class ? 'selected' : ''; ?>>
                            <?php echo $c['class_name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Start Date</label>
                <input type="date" name="start_date" required value="<?php echo $exam['start_date']; ?>">
            </div>
            <div class="form-group">
                <label>End Date</label>
                <input type="date" name="end_date" required value="<?php echo $exam['end_date']; ?>">
            </div>
        </div>
    </div>

    <!-- SECTION 2: SUBJECTS -->
    <div class="glass" style="padding: 1.5rem; border-radius: 1rem; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3 style="color: var(--primary-color);">2. Manage Subjects</h3>
            <button type="button" class="btn btn-primary" onclick="addSubjectRow()">
                <i class="fas fa-plus"></i> Add Subject
            </button>
        </div>
        
        <table class="table" style="width: 100%;">
            <thead>
                <tr>
                    <th>Subject Name</th>
                    <th>Code (Opt)</th>
                    <th width="100">Max Marks</th>
                    <th width="100">Pass Marks</th>
                    <th width="50"></th>
                </tr>
            </thead>
            <tbody id="subjectTableBody">
                <?php foreach ($subjects as $idx => $sub): ?>
                    <tr>
                        <td>
                            <input type="hidden" name="subjects[<?php echo $idx; ?>][id]" value="<?php echo $sub['id']; ?>">
                            <input type="text" name="subjects[<?php echo $idx; ?>][name]" value="<?php echo $sub['subject_name']; ?>" required style="width: 100%;">
                        </td>
                        <td><input type="text" name="subjects[<?php echo $idx; ?>][code]" value="<?php echo $sub['subject_code']; ?>" style="width: 100%;"></td>
                        <td><input type="number" name="subjects[<?php echo $idx; ?>][max]" value="<?php echo $sub['max_marks']; ?>" required style="width: 100%;"></td>
                        <td><input type="number" name="subjects[<?php echo $idx; ?>][pass]" value="<?php echo $sub['pass_marks']; ?>" required style="width: 100%;"></td>
                        <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (empty($subjects)): ?>
            <p id="noSubMsg" style="text-align:center; color:grey; margin-top:1rem;">No subjects added. Add subjects before entering marks.</p>
        <?php endif; ?>
    </div>

    <!-- SECTION 3: MARKS GRID -->
    <?php if ($target_class && !empty($subjects)): ?>
    <div class="glass" style="padding: 0; border-radius: 1rem; overflow: hidden; margin-bottom: 2rem;">
        <div style="padding: 1rem; background: rgba(99, 102, 241, 0.1); font-weight: bold; border-bottom: 1px solid var(--border);">
            3. Student Marks Entry
        </div>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; min-width: 800px;">
                <thead style="background: #f9fafb;">
                    <tr>
                        <th style="padding: 1rem; text-align: left; border-bottom: 2px solid #ddd; position: sticky; left: 0; background: #f9fafb; z-index: 10;">Student</th>
                        <?php foreach ($subjects as $sub): ?>
                            <th style="padding: 1rem; text-align: center; border-bottom: 2px solid #ddd;">
                                <?php echo $sub['subject_name']; ?><br>
                                <small style="font-weight: normal; color: grey;">(Max <?php echo $sub['max_marks']; ?>)</small>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="<?php echo count($subjects) + 1; ?>" style="text-align:center; padding: 2rem;">No students in class.</td></tr>
                    <?php endif; ?>
                    
                    <?php foreach ($students as $stu): 
                        $sid = $stu['id'];
                    ?>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 1rem; font-weight: 500; position: sticky; left: 0; background: white; z-index: 5; border-right: 2px solid #eee;">
                                <?php echo $stu['full_name']; ?><br>
                                <span style="font-size: 0.8rem; color: grey;"><?php echo $stu['username']; ?></span>
                            </td>
                            <?php foreach ($subjects as $sub): 
                                $sub_id = $sub['id'];
                                $val = isset($marks_data[$sid][$sub_id]) ? $marks_data[$sid][$sub_id]['marks_obtained'] : '';
                                $abs = isset($marks_data[$sid][$sub_id]) && $marks_data[$sid][$sub_id]['is_absent'] ? 'checked' : '';
                            ?>
                                <td style="padding: 0.5rem; text-align: center; border-right: 1px solid #eee;">
                                    <div style="display: flex; gap: 5px; justify-content: center; align-items: center;">
                                        <input type="number" step="0.5" 
                                               name="marks[<?php echo $sid; ?>][<?php echo $sub_id; ?>][obt]" 
                                               value="<?php echo $val; ?>" 
                                               class="mark-input"
                                               style="width: 70px; padding: 5px; border: 1px solid #ccc; text-align: center;"
                                               <?php echo $abs ? 'disabled' : ''; ?>>
                                        
                                        <label title="Absent" style="cursor: pointer;">
                                            <input type="checkbox" 
                                                   name="marks[<?php echo $sid; ?>][<?php echo $sub_id; ?>][absent]" 
                                                   <?php echo $abs; ?> 
                                                   onchange="toggleAbs(this)"> AB
                                        </label>
                                    </div>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- ACTIONS -->
    <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-bottom: 3rem; align-items: center;">
        
        <div style="display: flex; gap: 0.5rem; align-items: center; background: white; padding: 0.5rem; border-radius: 0.5rem;">
            <label>Schedule:</label>
            <input type="date" name="pub_date" min="<?php echo date('Y-m-d'); ?>">
            <input type="time" name="pub_time">
            <button type="submit" name="schedule_publish" class="btn" style="background: #3b82f6; color: white;">
                <i class="fas fa-clock"></i> Schedule
            </button>
        </div>

        <button type="submit" name="save_draft" class="btn" style="background: #6b7280; color: white; padding: 0.75rem 1.5rem;">
            <i class="fas fa-save"></i> Save Draft
        </button>

        <button type="submit" name="publish_now" class="btn" style="background: #10b981; color: white; padding: 0.75rem 2rem; font-size: 1.1rem;">
            <i class="fas fa-rocket"></i> Publish Result
        </button>
    </div>
    
    <?php else: ?>
        <?php if ($target_class): ?>
            <div style="padding: 2rem; text-align: center; background: #fff7ed; color: #9a3412; border-radius: 1rem; margin-bottom: 2rem;">
                <p>Please add at least one subject and click "Save Draft" to generate the entry grid.</p>
                <button type="submit" name="save_draft" class="btn btn-primary">Save & Generate Grid</button>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</form>

<script>
    function saveDraftAndReload(classId) {
        window.location.href = '?sel_class=' + classId + '<?php echo $exam_id ? "&edit_id=$exam_id" : ""; ?>';
    }

    function addSubjectRow() {
        let index = document.querySelectorAll('#subjectTableBody tr').length + 100;
        let html = `
            <tr>
                <td>
                    <input type="text" name="subjects[${index}][name]" placeholder="Subject Name" required style="width: 100%;">
                </td>
                <td><input type="text" name="subjects[${index}][code]" placeholder="Code" style="width: 100%;"></td>
                <td><input type="number" name="subjects[${index}][max]" value="100" required style="width: 100%;"></td>
                <td><input type="number" name="subjects[${index}][pass]" value="40" required style="width: 100%;"></td>
                <td><button type="button" class="btn btn-sm btn-danger" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
            </tr>
        `;
        document.getElementById('subjectTableBody').insertAdjacentHTML('beforeend', html);
        document.getElementById('noSubMsg').style.display = 'none';
    }

    function removeRow(btn) {
        if(confirm('Remove this subject? If saved, marks may be lost.')) {
            btn.closest('tr').remove();
        }
    }

    function toggleAbs(chk) {
        let input = chk.closest('div').querySelector('.mark-input');
        if(chk.checked) {
            input.disabled = true;
            input.style.background = '#f3f4f6';
        } else {
            input.disabled = false;
            input.style.background = 'white';
        }
    }
</script>

<?php include '../includes/footer.php'; ?>
