<?php
require 'config.php';

echo "<h2>Updating Database for Bulk Student & Security Features...</h2>";

// 1. Add is_first_login to users
$sql = "SHOW COLUMNS FROM users LIKE 'is_first_login'";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    $sql = "ALTER TABLE users ADD COLUMN is_first_login BOOLEAN DEFAULT FALSE";
    if ($conn->query($sql) === TRUE) {
        echo "Column 'is_first_login' added to users table.<br>";
    } else {
        echo "Error adding 'is_first_login': " . $conn->error . "<br>";
    }
} else {
    echo "Column 'is_first_login' already exists.<br>";
}

// 2. Add failed_login_attempts and lockout_time to users (for brute force protection)
$sql = "SHOW COLUMNS FROM users LIKE 'failed_login_attempts'";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    $sql = "ALTER TABLE users ADD COLUMN failed_login_attempts INT DEFAULT 0";
    $conn->query($sql);
    echo "Column 'failed_login_attempts' added.<br>";
}

$sql = "SHOW COLUMNS FROM users LIKE 'lockout_time'";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    $sql = "ALTER TABLE users ADD COLUMN lockout_time TIMESTAMP NULL DEFAULT NULL";
    $conn->query($sql);
    echo "Column 'lockout_time' added.<br>";
}

echo "<h3>Database Update Complete!</h3>";
?>