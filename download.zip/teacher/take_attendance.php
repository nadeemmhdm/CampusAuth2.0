<?php
require '../config.php';

if (!isset($_SESSION['user_id'])) {
    redirect('../index.php');
}
// Allow teacher OR temp_teacher
if ($_SESSION['role'] !== 'teacher' && $_SESSION['role'] !== 'temp_teacher') {
    redirect('../index.php');
}

$teacher_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$date = date('Y-m-d'); // STRICT: ONLY TODAY
$message = '';

// Get assigned classes
if ($role == 'temp_teacher') {
    $temp_cid = $_SESSION['temp_class_id'];
    $classes = $conn->query("SELECT * FROM classes WHERE id = $temp_cid");
} else {
    $classes = $conn->query("SELECT * FROM classes WHERE tutor_id = $teacher_id");
}

// Selected Class
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;

// Auto-select for temp teacher
if ($role == 'temp_teacher' && $class_id != $_SESSION['temp_class_id']) {
    $class_id = $_SESSION['temp_class_id'];
}

// Verify class ownership
if ($class_id) {
    if ($role == 'teacher') {
        $check = $conn->query("SELECT id FROM classes WHERE id=$class_id AND tutor_id=$teacher_id");
        if ($check->num_rows == 0)
            $class_id = 0;
    } elseif ($role == 'temp_teacher') {
        if ($class_id != $_SESSION['temp_class_id'])
            $class_id = 0;
    }
}

// Handle Mark Attendance (Insert Only for Unmarked)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_attendance'])) {
    if (isset($_POST['students']) && is_array($_POST['students'])) {
        $count_inserted = 0;

        foreach ($_POST['students'] as $student_id => $data) {
            // Check if status is sent
            if (!isset($data['status']))
                continue;

            $status = $conn->real_escape_string($data['status']);
            $sid = intval($student_id);

            // Double Check: Does attendance exist?
            $check = $conn->query("SELECT id FROM attendance WHERE student_id = $sid AND date = '$date'");
            if ($check->num_rows == 0) {
                // Insert
                $conn->query("INSERT INTO attendance (student_id, class_id, date, status, marked_by) 
                              VALUES ($sid, $class_id, '$date', '$status', $teacher_id)");
                $count_inserted++;
            }
        }

        if ($count_inserted > 0) {
            $message = "Saved attendance for $count_inserted students.";
        } else {
            $message = "No new changes saved (Students might be already marked).";
        }
    }
}

// Fetch Students & Existing Attendance
$students = [];
$attendance_map = [];
$any_unmarked = false;

if ($class_id) {
    // 1. Get existing attendance map for today
    $att_res = $conn->query("SELECT student_id, status FROM attendance WHERE class_id=$class_id AND date='$date'");
    while ($row = $att_res->fetch_assoc()) {
        $attendance_map[$row['student_id']] = $row['status'];
    }

    // 2. Get All Students
    $res = $conn->query("SELECT * FROM users WHERE class_id=$class_id AND role='student' ORDER BY username ASC");
    while ($row = $res->fetch_assoc()) {
        $sid = $row['id'];
        if (isset($attendance_map[$sid])) {
            $row['att_status'] = $attendance_map[$sid];
            $row['is_marked'] = true;
        } else {
            $row['att_status'] = '';
            $row['is_marked'] = false;
            $any_unmarked = true;
        }
        $students[] = $row;
    }
}
?>
<?php include '../includes/header.php'; ?>

<h2 class="mb-4">Mark Attendance (<?php echo date('d M Y'); ?>)</h2>

<?php if ($message): ?>
    <div style="padding: 1rem; background: #d1fae5; color: #065f46; border-radius: 0.5rem; margin-bottom: 1rem;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<!-- Class Selector -->
<form method="GET" class="glass" style="padding: 1rem; margin-bottom: 2rem;">
    <label>Select Class</label>
    <select name="class_id" onchange="this.form.submit()">
        <option value="">-- Select --</option>
        <?php
        $classes->data_seek(0);
        while ($c = $classes->fetch_assoc()): ?>
            <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $class_id ? 'selected' : ''; ?>>
                <?php echo $c['class_name']; ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<?php if ($class_id && count($students) > 0): ?>

    <form method="POST">
        <style>
            /* Radio Button Logic */
            .status-item input:checked+span {
                font-weight: bold;
            }

            .status-item input:checked+span.p-span {
                background: #d1fae5;
                color: #065f46;
                box-shadow: 0 0 0 2px #10b981;
            }

            .status-item input:checked+span.a-span {
                background: #fee2e2;
                color: #991b1b;
                box-shadow: 0 0 0 2px #ef4444;
            }

            .status-item input:checked+span.h-span {
                background: #ffedd5;
                color: #9a3412;
                box-shadow: 0 0 0 2px #f97316;
            }

            .status-badge {
                padding: 0.5rem 1rem;
                border-radius: 2rem;
                border: 1px solid #ddd;
                cursor: pointer;
                transition: all 0.2s;
            }

            .disabled-row {
                background: #f9fafb;
                opacity: 0.8;
            }
        </style>

        <div class="glass" style="border-radius: 1rem; overflow: hidden;">
            <?php foreach ($students as $s): ?>
                <div
                    style="padding: 1rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; <?php echo $s['is_marked'] ? 'background: #fdfafa;' : ''; ?>">

                    <!-- User Info -->
                    <div>
                        <strong><?php echo $s['full_name']; ?></strong>
                        <div class="text-muted" style="font-size: 0.8rem;"><?php echo $s['username']; ?></div>
                        <?php if ($s['is_marked']): ?>
                            <small style="color: grey;"><i class="fas fa-lock"></i> Already Saved</small>
                        <?php else: ?>
                            <small style="color: blue;"><i class="fas fa-pen"></i> Needs Marking</small>
                        <?php endif; ?>
                    </div>

                    <!-- Actions -->
                    <div style="display: flex; gap: 1rem; align-items: center;">

                        <?php if ($s['is_marked']): ?>
                            <!-- LOCKED VIEW -->
                            <?php
                            $st = $s['att_status'];
                            $color = ($st == 'present') ? 'green' : (($st == 'absent') ? 'red' : 'orange');
                            ?>
                            <span style="font-weight: bold; color: <?php echo $color; ?>; margin-right: 1rem;">
                                <?php echo ucfirst(str_replace('_', ' ', $st)); ?>
                            </span>

                            <?php if ($role !== 'temp_teacher'): ?>
                                <a href="request_edit.php?student_id=<?php echo $s['id']; ?>&class_id=<?php echo $class_id; ?>"
                                    class="btn"
                                    style="padding: 0.25rem 0.5rem; background: var(--warning-color); color: white; font-size: 0.75rem;">
                                    Request Edit
                                </a>
                            <?php endif; ?>

                        <?php else: ?>
                            <!-- EDITABLE VIEW -->
                            <label class="status-item">
                                <input type="radio" name="students[<?php echo $s['id']; ?>][status]" value="present" required
                                    style="display:none;">
                                <span class="status-badge p-span">Present</span>
                            </label>

                            <label class="status-item">
                                <input type="radio" name="students[<?php echo $s['id']; ?>][status]" value="absent"
                                    style="display:none;">
                                <span class="status-badge a-span">Absent</span>
                            </label>

                            <label class="status-item">
                                <input type="radio" name="students[<?php echo $s['id']; ?>][status]" value="half_day"
                                    style="display:none;">
                                <span class="status-badge h-span">Half Day</span>
                            </label>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($any_unmarked): ?>
            <div style="margin-top: 2rem; text-align: right;">
                <button type="submit" name="submit_attendance" class="btn btn-primary" style="padding: 1rem 3rem;">
                    <i class="fas fa-save"></i> Save Unmarked
                </button>
            </div>
        <?php else: ?>
            <div
                style="margin-top: 2rem; text-align: center; color: green; padding: 1rem; background: #d1fae5; border-radius: 0.5rem;">
                <i class="fas fa-check-circle"></i> All students for this class have been marked for today.
            </div>
        <?php endif; ?>

    </form>

<?php elseif ($class_id): ?>
    <p>No students found in this class.</p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>